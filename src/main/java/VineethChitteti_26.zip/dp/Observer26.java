package dp;

public abstract class Observer26 {

    protected StudentRepository26 studentRepository26;
    public abstract void update();
}
