package dp;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import java.util.Iterator;


public class ObserverPlotter2 extends Observer26 {


    private StudentRepository26 studentRepository26;
    private ApplicationFrame applicationFrame;

    public ObserverPlotter2(StudentRepository26 repository) {

        this.studentRepository26 = repository;
        this.applicationFrame = new ApplicationFrame("Group 26");
    }

    @Override
    public void update() {
        // update the UI, whenever repository changes
        JFreeChart barChart = ChartFactory.createBarChart(
                "Student bar chart",
                "Category",
                "Score",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);


        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        applicationFrame.setContentPane(chartPanel);
//        setContentPane( chartPanel );
    }

    private CategoryDataset createDataset() {

        final String assignment1 = "Assign 01";
        final String assignment2 = "Assign 02";
        final String assignment3 = "Assign 03";
        final String quiz01 = "Quiz 01";
        final DefaultCategoryDataset dataset =
                new DefaultCategoryDataset();

        synchronized (studentRepository26) {
            if(studentRepository26 != null) {

                for (Iterator<Student26> it = studentRepository26.getIterator(); it.hasNext(); ) {
                    Student26 student26 = it.next();
                    dataset.addValue(student26.getAssign1Score(), student26.getID(), assignment1);
                    dataset.addValue(student26.getAssign2Score(), student26.getID(), assignment2);
                    dataset.addValue(student26.getAssign3Score(), student26.getID(), assignment3);
                    dataset.addValue(student26.getQuiz01Score(), student26.getID(), quiz01);
                }
            }
        }

        return dataset;
    }

    private ApplicationFrame getApplicationFrame() {

        return applicationFrame;
    }

    private static void createAndAddStudentsToRepository(StudentRepository26 studentRepository26) {

        Student26 student261 = new Student26(1, 10, 20, 30, 40);
        Student26 student262 = new Student26(2, 90, 40, 80, 20);
        Student26 student263 = new Student26(3, 60, 30, 10, 20);
        Student26 student264 = new Student26(4, 20, 20, 40, 30);
        studentRepository26.addStudent(student261);
        studentRepository26.addStudent(student262);
        studentRepository26.addStudent(student263);
        studentRepository26.addStudent(student264);
    }

    /*
    Main method to test Observer Plotter
     */
    public static void main(String[] args) {
        StudentRepository26 studentRepository26 = new StudentRepository26();
        createAndAddStudentsToRepository(studentRepository26);

        ObserverPlotter2 observer = new ObserverPlotter2(studentRepository26);
        observer.update();
        observer.getApplicationFrame().pack();
        RefineryUtilities.centerFrameOnScreen(observer.getApplicationFrame());
        observer.getApplicationFrame().setVisible(true);
        System.out.println();
    }
}
