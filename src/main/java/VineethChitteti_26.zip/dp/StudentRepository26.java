package dp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StudentRepository26 {

    private List<Student26> list;
    private Iterator<Student26> iterator;

    public StudentRepository26() {

        list = new ArrayList<>();
        this.iterator = list.iterator();
    }

    public Iterator<Student26> getIterator() {
        if (list != null)
            iterator = list.iterator();
        return this.iterator;
    }

    public void addStudent(Student26 student26) {
        if (list == null)
            list = new ArrayList<>();

        list.add(student26);
    }
}
