package dp;

public class Student {

    private Integer ID;
    private float assign1Score;
    private float assign2Score;
    private float assign3Score;
    private float quiz01Score;

    public Student(Integer ID, float assign1Score, float assign2Score, float assign3Score, float quiz01Score) {

        this.ID = ID;
        this.assign1Score = assign1Score;
        this.assign2Score = assign2Score;
        this.assign3Score = assign3Score;
        this.quiz01Score = quiz01Score;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public float getAssign1Score() {
        return assign1Score;
    }

    public void setAssign1Score(float assign1Score) {
        this.assign1Score = assign1Score;
    }

    public float getAssign2Score() {
        return assign2Score;
    }

    public void setAssign2Score(float assign2Score) {
        this.assign2Score = assign2Score;
    }

    public float getAssign3Score() {
        return assign3Score;
    }

    public void setAssign3Score(float assign3Score) {
        this.assign3Score = assign3Score;
    }

    public float getQuiz01Score() {
        return quiz01Score;
    }

    public void setAssign4Score(float assign4Score) {
        this.quiz01Score = assign4Score;
    }
}
