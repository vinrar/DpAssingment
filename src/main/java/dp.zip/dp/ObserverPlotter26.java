package dp;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import javax.swing.*;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;


public class ObserverPlotter26 implements Observer {


    private StudentRepository studentRepository;
    private ApplicationFrame applicationFrame;
    ChartPanel chartPanel;

    public ObserverPlotter26() {

        this.applicationFrame = new ApplicationFrame("Group 26");
    }

    public JPanel getPanel() {
        return this.chartPanel;
    }

    private CategoryDataset createDataset() {

        final String assignment1 = "Assign 01";
        final String assignment2 = "Assign 02";
        final String assignment3 = "Assign 03";
        final String quiz01 = "Quiz 01";
        final DefaultCategoryDataset dataset =
                new DefaultCategoryDataset();

        if(studentRepository != null) {

            for (Iterator<Student> it = studentRepository.getIterator(); it.hasNext(); ) {
                Student student = it.next();
                dataset.addValue(student.getAssign1Score(), student.getID(), assignment1);
                dataset.addValue(student.getAssign2Score(), student.getID(), assignment2);
                dataset.addValue(student.getAssign3Score(), student.getID(), assignment3);
                dataset.addValue(student.getQuiz01Score(), student.getID(), quiz01);
            }
        }

        return dataset;
    }

    private ApplicationFrame getApplicationFrame() {

        return applicationFrame;
    }

    private static void createAndAddStudentsToRepository(StudentRepository studentRepository) {

        Student student261 = new Student(1, 10, 20, 30, 40);
        Student student262 = new Student(2, 90, 40, 80, 20);
        Student student263 = new Student(3, 60, 30, 10, 20);
        Student student264 = new Student(4, 20, 20, 40, 30);
        studentRepository.addStudent(student261);
        studentRepository.addStudent(student262);
        studentRepository.addStudent(student263);
        studentRepository.addStudent(student264);
    }

    /*
    Main method to test Observer Plotter
     */
    public static void main(String[] args) {

        ObserverPlotter26 observer = new ObserverPlotter26();
        StudentRepository studentRepository = new StudentRepository();
        createAndAddStudentsToRepository(studentRepository);
        observer.update(studentRepository, null);
        observer.getApplicationFrame().pack();
        RefineryUtilities.centerFrameOnScreen(observer.getApplicationFrame());
        observer.getApplicationFrame().setVisible(true);
    }

    @Override
    public void update(Observable o, Object args) {

        this.studentRepository = (StudentRepository) o;
        // update the UI, whenever repository changes
        JFreeChart barChart = ChartFactory.createBarChart(
                "Student bar chart",
                "Category",
                "Score",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);


        chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        applicationFrame.setContentPane(chartPanel);
    }
}
