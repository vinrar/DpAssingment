package dp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;

public class StudentRepository extends Observable {

    private List<Student> list;
    private Iterator<Student> iterator;

    public StudentRepository() {

        list = new ArrayList<>();
        this.iterator = list.iterator();
    }

    public Iterator<Student> getIterator() {
        if (list != null)
            iterator = list.iterator();
        return this.iterator;
    }

    public void addStudent(Student student) {
        if (list == null)
            list = new ArrayList<>();

        list.add(student);
    }
}
